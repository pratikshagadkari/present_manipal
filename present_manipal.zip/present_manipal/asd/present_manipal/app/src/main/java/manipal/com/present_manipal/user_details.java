package manipal.com.present_manipal;

public class user_details {
    public String uname,email_id,regd_no,branch,phno;
    int year;

    public user_details() {
    }

    public user_details(String uname, String email_id, String regd_no) {
        this.uname = uname;
        this.email_id = email_id;
        this.regd_no = regd_no;
    }
    /*public String get_email(){

        return email_id;
    }
    public String get_name(){

        return uname;
    }
    public String get_regd(){

        return regd_no;
    }*/
}
