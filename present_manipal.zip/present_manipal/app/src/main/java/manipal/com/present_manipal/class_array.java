package manipal.com.present_manipal;

public class class_array {
    String room,time,day;

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public class_array(String room, String time, String day) {

        this.room = room;
        this.time = time;
        this.day = day;
    }
}
