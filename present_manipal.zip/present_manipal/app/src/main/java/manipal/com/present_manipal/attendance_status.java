package manipal.com.present_manipal;

public class attendance_status {
     String regd;
    String status;

    public attendance_status(String regd, String status) {
        this.regd= regd;
        this.regd = status;
    }
}
