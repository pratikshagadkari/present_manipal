package manipal.com.present_manipal;

public class disp_event {
    int a;
    String b,c,d;
    public disp_event(int a, String b,String c,String d) {
        this.a = a;
        this.b=b;
        this.c=c;
        this.d=d;
    }
}
