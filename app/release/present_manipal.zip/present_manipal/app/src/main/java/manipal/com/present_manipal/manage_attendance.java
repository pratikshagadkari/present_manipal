package manipal.com.present_manipal;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class manage_attendance extends AppCompatActivity {
    Spinner spin, spin2, spin3, spin4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_attendance);
        spin = findViewById(R.id.branch);
        spin2 = findViewById(R.id.year);
        spin3 = findViewById(R.id.subject);
        spin4 = findViewById(R.id.section);
        final String[] branch = new String[1];
        final String[] year = new String[1];
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                branch[0] =spin.getSelectedItem().toString();
                year[0] =spin2.getSelectedItem().toString();
                if(branch[0]==null)
                    Toast.makeText(manage_attendance.this,"Fill out Branch",Toast.LENGTH_SHORT).show();
                else if (year[0]==null)
                    Toast.makeText(manage_attendance.this,"Fill out Year",Toast.LENGTH_SHORT).show();
                final ArrayList<String> sublist = new ArrayList<>();
                sublist.add("Select Subject");
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Subject_List").child((branch[0] + year[0]));
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Iterator<DataSnapshot> iterable = dataSnapshot.getChildren().iterator();
                        for (Iterator<DataSnapshot> it = iterable; it.hasNext(); ) {
                            DataSnapshot dataSnapshot1 = it.next();
                            sublist.add(dataSnapshot1.getValue(String.class));}
                        ArrayAdapter<String> subAdapter = new ArrayAdapter<String>(manage_attendance.this, android.R.layout.simple_spinner_item, sublist);
                        subAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spin3.setAdapter(subAdapter);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                branch[0] =spin.getSelectedItem().toString();
                year[0] =spin2.getSelectedItem().toString();
                final ArrayList<String> sublist = new ArrayList<>();
                sublist.add("Select Subject");
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Subject_List").child((branch[0] + year[0]));
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Iterator<DataSnapshot> iterable = dataSnapshot.getChildren().iterator();
                        for (Iterator<DataSnapshot> it = iterable; it.hasNext(); ) {
                            DataSnapshot dataSnapshot1 = it.next();
                            sublist.add(dataSnapshot1.getValue(String.class));}
                        ArrayAdapter<String> subAdapter = new ArrayAdapter<String>(manage_attendance.this, android.R.layout.simple_spinner_item, sublist);
                        subAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spin3.setAdapter(subAdapter);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void view_class(View view) {
        String a,b,c,d;
        a=spin.getSelectedItem().toString();
        b=spin2.getSelectedItem().toString();
        c=spin3.getSelectedItem().toString();
        d=spin4.getSelectedItem().toString();
        classroom_details det=new classroom_details(a,b,c,d);
        Intent i=new Intent(manage_attendance.this,display_class.class);
        i.putExtra("branch",a);
        i.putExtra("semester",b);
        i.putExtra("section",c);
        i.putExtra("subject",d);
        startActivity(i);
    }
}
