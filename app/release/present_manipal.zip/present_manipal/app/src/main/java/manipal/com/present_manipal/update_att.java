package manipal.com.present_manipal;
public class update_att {
    public String strDate,text,subject;
    public update_att(String strDate, String text,String subject) {
        this.strDate=strDate;
        this.text=text;
        this.subject=subject;
    }
}
