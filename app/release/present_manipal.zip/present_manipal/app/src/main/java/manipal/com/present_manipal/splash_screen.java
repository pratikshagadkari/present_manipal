package manipal.com.present_manipal;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class splash_screen extends AppCompatActivity {
    int SPLASH_DISPLAY_LENGTH=3000;

FirebaseAuth auth;
FirebaseUser user;
FirebaseDatabase data;
DatabaseReference ref   ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
         SharedPreferences preferences=getSharedPreferences("User Info",MODE_PRIVATE);
        final int choice=preferences.getInt("Type", 0);
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                data = FirebaseDatabase.getInstance();
                auth = FirebaseAuth.getInstance();
                user = auth.getCurrentUser();
                ref = data.getReference();
                if (user != null) {
                    String s=user.getEmail();
                    int i=s.indexOf(".");
                    if (s.charAt(i + 1) == '1') {
                        Intent mainIntent = new Intent(splash_screen.this, student_mainpage.class);
                        startActivity(mainIntent);
                        finish();
                    } else {
                        Intent mainIntent = new Intent(splash_screen.this, teacher_mainpage.class);
                        startActivity(mainIntent);
                        finish();
                    }
                }
                else {
                    Intent mainIntent = new Intent(splash_screen.this, choice_page.class);
                    startActivity(mainIntent);
                    finish();
                }
            }
        },SPLASH_DISPLAY_LENGTH);
    }
}
