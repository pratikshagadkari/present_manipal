package manipal.com.present_manipal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class update_info_students extends AppCompatActivity {
    FirebaseDatabase data;
    FirebaseAuth auth;
    DatabaseReference ref;
    Spinner spin,spin2,spin3;
    EditText et1,et2,et3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_info);
        data=FirebaseDatabase.getInstance();
        et1=findViewById(R.id.email);
        et2=findViewById(R.id.phone);
        et3=findViewById(R.id.dob);
        auth=FirebaseAuth.getInstance();
        ref=data.getReference().child("Students").child(auth.getUid());
        spin=findViewById(R.id.br_sem);
        spin2=findViewById(R.id.sem_spinner);
        spin3=findViewById(R.id.sec_spinner);
    }

    public void update(View view) {
        String a=spin.getSelectedItem().toString();
        String b=spin2.getSelectedItem().toString();
        String c=spin3.getSelectedItem().toString();
        String ab=a+b+c;
        String set1=et1.getText().toString();
        String set2=et2.getText().toString();
        String set3=et3.getText().toString();
        ref.child("add_details").setValue(ab);
        ref.child("phone_no").setValue(set2);
        ref.child("personal_email_id").setValue(set1);
        ref.child("dob").setValue(set3);
        Intent i=new Intent(update_info_students.this,student_mainpage.class);
        Toast.makeText(update_info_students.this,"Details Updated",Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
}
