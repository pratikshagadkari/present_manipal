package manipal.com.present_manipal;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class teacher_registration extends AppCompatActivity {
    FirebaseAuth auth;
    EditText a, b, c,d;
    FirebaseDatabase data;
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_registration);
        a = findViewById(R.id.teach_name);
        b = findViewById(R.id.teach_email);
        c = findViewById(R.id.teach_pass);
        d = findViewById(R.id.teach_id);
        auth=FirebaseAuth.getInstance();
        data=FirebaseDatabase.getInstance();
        ref=data.getReference();
    }

    public void register(View view) {

        final String name = a.getText().toString().trim();
        if(TextUtils.isEmpty(name)){
            Toast.makeText(this,"Name Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        final String email = b.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Email Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        final String pass = c.getText().toString().trim();
        if(TextUtils.isEmpty(pass)){
            Toast.makeText(this,"Password Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        if(pass.length()<6){
            Toast.makeText(this,"Password Length Should Be Greater Than 6",Toast.LENGTH_SHORT).show();
            return;}
        final String registration=d.getText().toString();
        if(TextUtils.isEmpty(registration)){
            Toast.makeText(this,"Registration Number Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        Toast.makeText(teacher_registration.this,"Please wait we are trying to connect to the servers",Toast.LENGTH_SHORT).show();
        final String type="2";
        final String first_time="empty";
        int i=email.lastIndexOf("@");
        //if(email.substring(i+1,email.length()).compareTo("muj.manipal.edu")==0) {
            auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        auth.getCurrentUser().sendEmailVerification();
                        Toast.makeText(teacher_registration.this, "Registration Successful Please Verify Email and Login", Toast.LENGTH_SHORT).show();
                        user_details user = new user_details(name, email, registration,type,first_time);
                        ref.child("Teachers").child(auth.getUid()).setValue(user);
                        Intent i = new Intent(teacher_registration.this, teacherlogin.class);
                        auth.signOut();
                        startActivity(i);
                        finish();
                    } else
                        Toast.makeText(teacher_registration.this, "Registration Unsuccessful", Toast.LENGTH_SHORT).show();
                }
            });
       // }
        //else
          //  Toast.makeText(teacher_registration.this,"Please Enter Email Id Provided By College",Toast.LENGTH_SHORT).show();
    }
}