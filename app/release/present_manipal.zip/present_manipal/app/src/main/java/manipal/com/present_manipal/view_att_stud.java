package manipal.com.present_manipal;

import android.app.Dialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.opencensus.internal.StringUtil;

public class view_att_stud extends AppCompatActivity {
    FirebaseDatabase data;
    FirebaseAuth auth;
    DatabaseReference ref;
    String details,regd;
    TextView txt1;
    Dialog mydialog;
    Button but;
    TextView x,y,z;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        txt1=findViewById(R.id.show);
        setContentView(R.layout.activity_view_att_stud);
        data=FirebaseDatabase.getInstance();
        auth=FirebaseAuth.getInstance();
        ref=data.getReference();
        mydialog=new Dialog(this);
        String asd=auth.getUid();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            regd = extras.getString("regd_no");
            Log.d("xyz",regd);
        }
        data.getReference().child("Students").child(asd).child("add_details").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                details= dataSnapshot.getValue().toString();
                final String abc=details.substring(0,details.length()-1);
                final String abc1=details.substring(abc.length(),details.length());
                Log.d("abcd",abc);
                Log.d("abcd",abc1);
                data.getReference().child("Subject_List").child(abc).addValueEventListener(new ValueEventListener() {
                    int c=1;
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(final DataSnapshot child : dataSnapshot.getChildren() ){
                            Button myButton = new Button(view_att_stud.this);
                            myButton.setText(child.getValue().toString());
                            myButton.setId(c);
                            c++;
                            LinearLayout ll = findViewById(R.id.lay);
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                            ll.addView(myButton, lp);

                            myButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    data.getReference().child("Attendance").child(abc).child(abc1).child(child.getValue().toString()).addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            if(dataSnapshot.exists())
                                            {
                                                double count_present=0.00,count_absent=0.00;
                                                for (DataSnapshot dsp:dataSnapshot.getChildren()) {//date
                                                    Log.d("snap",dsp.getValue().toString());
                                                    for(DataSnapshot dsp1:dsp.getChildren()){//hour
                                                        Log.d("snap1",dsp1.getValue().toString());
                                                        for(DataSnapshot dsp2:dsp1.getChildren()){//regd
                                                            if(dsp2.getKey().equals(regd)){
                                                                if(dsp2.getValue().toString().equals("Present"))
                                                                    count_present++;
                                                                else
                                                                    count_absent++;
                                                            }

                                                        }
                                                    }
                                                }
                                                double total_class=count_absent+count_present;
                                                double percentage=0.00;
                                                try {
                                                     percentage= (count_present * 100 / total_class);
                                                }
                                                catch (Exception e){
                                                    Toast.makeText(view_att_stud.this,"Error in Retrieveing Data",Toast.LENGTH_SHORT).show();
                                                }
                                                mydialog.setContentView(R.layout.popup_attendance);
                                                x=mydialog.findViewById(R.id.a);
                                                y=mydialog.findViewById(R.id.b);
                                                z=mydialog.findViewById(R.id.c);
                                                x.setText("Number Of Present= "+(int)count_present);
                                                y.setText("Total Number Of Classes= "+(int)total_class);
                                                z.setText("Attendance Percentage= "+percentage+"%");
                                                but=mydialog.findViewById(R.id.close_dialog);
                                                mydialog.setCanceledOnTouchOutside(true);
                                                but.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        mydialog.dismiss();
                                                    }
                                                });
                                                mydialog.setCancelable(true);
                                                try {
                                                    mydialog.show();
                                                } catch(Exception e){

                                                }
                                            }
                                            else {
                                                Toast.makeText(view_att_stud.this,"Data Does Not Exist",Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                }
                            });
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        mydialog.dismiss();
        super.onBackPressed();
    }
}
