package manipal.com.present_manipal;

public class classroom_details {
    static String branch;
    static String year;
    static String subject;
    static String section;

    public classroom_details(String branch, String year, String subject, String section) {
        this.branch = branch;
        this.year = year;
        this.subject = subject;
        this.section = section;
    }

    public classroom_details() {

    }
}
