package manipal.com.present_manipal;

public class disp_event {
    int a;
    String b;
    public disp_event(int a, String b) {
        this.b=b;
        this.a = a;
    }
}
