package manipal.com.present_manipal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class eventadapter extends RecyclerView.Adapter<eventadapter.ViewHolder> {
    public Context mContext;
    ArrayList<disp_event> list;

    public eventadapter(Context mContext, ArrayList<disp_event> list) {
        this.mContext = mContext;
        this.list=list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(mContext);
        View view=layoutInflater.inflate(R.layout.events_layout,parent,false);
        eventadapter.ViewHolder viewHolder=new eventadapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ImageView a;
        Button b;
        a=holder.a;
        b=holder.b;
        holder.a.setImageResource(list.get(position).a);
        b.setText(""+list.get(position).b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.google.com/"));
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView a;
        Button b;
        public ViewHolder(View itemView) {
            super(itemView);
            a=itemView.findViewById(R.id.event_image);
            b=itemView.findViewById(R.id.go_page);
        }
    }
}
