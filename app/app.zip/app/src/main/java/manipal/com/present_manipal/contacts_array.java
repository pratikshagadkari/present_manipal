package manipal.com.present_manipal;

public class contacts_array {
    String name;
    String email;
    String phone;
    public contacts_array(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }


}
