import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class content_teacher_mainpage extends AppCompatActivity {
    ListView lst;
    String[] events={"Oneiros","Abhivarta","Techideate"};

}
